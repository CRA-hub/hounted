# Haunted House: Last One Alive — V3

A room-code multiplayer cinematic survival horror prototype built with Node.js, Express, and Socket.IO.

## V3 gameplay
- 3–12 players, synchronized room state, host-controlled start/restart
- Secret killer role assigned on the server and privately sent to each player
- Separate survivor and killer choices
- Survivors investigate, search, hide, protect a player, or work on escape
- Killer can stalk, set traps, plant false evidence, strike, or stay quiet
- Shared evidence board, private clues, health, sanity, escape progress
- Final accusation vote and multiple endings
- Responsive horror-themed UI and a synthesized ambient sound toggle

## Run locally
1. Install Node.js 18 or newer.
2. Extract this ZIP.
3. In the extracted folder, run `npm install` and then `npm start`.
4. Open `http://localhost:3000`.

## Publish for friends
Deploy the project as a persistent Node.js web service on a WebSocket-capable host such as Render or Railway. Use `npm install` as the install/build command and `npm start` as the start command. A static-only hosting service is not enough for Socket.IO multiplayer. Once deployed, share the host's public HTTPS URL with friends.

This is a playable prototype; before a large public launch, add reconnection handling, room cleanup, moderation/rate limits, and more balance testing.
